<?xml version="1.0" ?><!DOCTYPE TS><TS language="ru" version="2.1">
<context>
    <name>CloneJob</name>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="146"/>
        <source>Writing data to %1 failed, expected write size: %2 — only %3 written, error: %4</source>
        <translation>Ошибка записи данных в %1, ожидаемый размер записи: %2 - только %3 записано, с ошибками: %4</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="193"/>
        <source>%1 not exist</source>
        <translation>%1 не существует</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="207"/>
        <location filename="../src/corelib/clonejob.cpp" line="235"/>
        <source>%1 invalid or not exist</source>
        <translation>%1 недействительно или не существует</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="219"/>
        <source>Disk only can be cloned to disk</source>
        <translation>Диск можно клонировать только на диск</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="241"/>
        <source>%1 total capacity is less than maximum readable data on %2</source>
        <translation>%1 общая емкость меньше максимально читаемых данных %2</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="255"/>
        <source>Failed to change %1 size, please check the free space on target disk</source>
        <translation>Не удалось изменить размер %1, пожалуйста, проверьте свободное место на целевом диске</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="243"/>
        <location filename="../src/widgets/mainwindow.cpp" line="615"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="349"/>
        <source>Select Operation</source>
        <translation>Выбор Операции</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="350"/>
        <source>Next</source>
        <translation>Далее</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="374"/>
        <location filename="../src/widgets/mainwindow.cpp" line="837"/>
        <source>Backup</source>
        <translation>Резервная копия</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="376"/>
        <location filename="../src/widgets/mainwindow.cpp" line="839"/>
        <source>Clone</source>
        <translation>Клонирование</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="379"/>
        <location filename="../src/widgets/mainwindow.cpp" line="386"/>
        <source>Target disk will be permanently overwritten, please confirm to continue</source>
        <translation>Целевой диск будет постоянно перезаписываться, пожалуйста подтвердите для продолжения</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="381"/>
        <location filename="../src/widgets/mainwindow.cpp" line="388"/>
        <source>Target partition will be permanently overwritten, please confirm to continue</source>
        <translation>Целевой диск будет постоянно перезаписываться, пожалуйста подтвердите для продолжения</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="383"/>
        <location filename="../src/widgets/mainwindow.cpp" line="841"/>
        <source>Restore</source>
        <translation>Восстановить</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="400"/>
        <source>Please move image file to other location outside the disk to avoid data loss</source>
        <translation>Переместите файл образа в другое место за пределами диска, чтобы избежать потери данных.</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="402"/>
        <source>Please move image file to other location outside the partition to avoid data loss</source>
        <translation>Переместите файл образа в другое место за пределами диска, чтобы избежать потери данных.</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="415"/>
        <source>Storage location can not be in the disk to backup, please reselect</source>
        <translation>Место хранения не может быть на диске для резервного копирования, пожалуйста повторите</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="417"/>
        <source>Storage location can not be in the partition to backup, please reselect</source>
        <translation>Место хранения не может быть на диске для резервного копирования, пожалуйста повторите</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="492"/>
        <source>Proceed to clone?</source>
        <translation>Начать клонирование?</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="495"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="496"/>
        <location filename="../src/widgets/mainwindow.cpp" line="547"/>
        <location filename="../src/widgets/mainwindow.cpp" line="665"/>
        <location filename="../src/widgets/mainwindow.cpp" line="788"/>
        <source>OK</source>
        <translation>ОК</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="512"/>
        <location filename="../src/widgets/mainwindow.cpp" line="593"/>
        <source>The selected storage location not found</source>
        <translation>Выбранное место хранения не найдено</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="652"/>
        <source>Task completed</source>
        <translation>Задача завершена</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="664"/>
        <source>Clone Successful</source>
        <translation>Клонирование Успешно Завершено</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="668"/>
        <source>Restore Succeessful</source>
        <translation>Восстановление Успешно Завершено</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="736"/>
        <source>Failed to restart system</source>
        <translation>Ошибка перезапуска системы</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="770"/>
        <source>Failed to restart &quot;Deepin Recovery&quot;</source>
        <translation>Не удалось перезапустить «Deepin Recovery»</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="542"/>
        <source>Restart to Continue</source>
        <translation>Перезапустить для Продолжения</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="239"/>
        <source>Restore boot</source>
        <translation>Восстановить загрузку</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="436"/>
        <source>No enough total capacity in target disk, please select another one</source>
        <translation>Недостаточно места на целевом диске, выберите другой</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="438"/>
        <source>No enough total capacity in target partition, please select another one</source>
        <translation>Недостаточно места на целевом диске, выберите другой</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="463"/>
        <source>No enough total capacity, please select another disk</source>
        <translation>Недостаточно места на целевом диске, выберите другой диск</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="493"/>
        <source>All data in the target disk (partition) will be formatted during cloning or restoring, which cannot be cancelled during the process.</source>
        <translation>Все данные на целевом диске (разделе) будут отформатированы во время клонирования или восстановления, которые нельзя отменить во время процесса.</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="526"/>
        <location filename="../src/widgets/mainwindow.cpp" line="581"/>
        <source>%1 not exist</source>
        <translation>%1 не существует</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="545"/>
        <source>&quot;%1&quot; is used, please restart and enter &quot;Deepin Recovery&quot; to continue</source>
        <translation>&quot;%1&quot; используется, перезапустите и введите «Deepin Recovery», для продолжения</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="550"/>
        <source>&quot;%1&quot; is used, please install &quot;Deepin Recovery&quot; to retry</source>
        <translation>&quot;%1&quot; используется, пожалуйста установите «Deepin Recovery», чтобы повторить попытку</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="609"/>
        <source>Performing Backup</source>
        <translation>Выполнение Резервного копирования</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="611"/>
        <source>Cloning</source>
        <translation>Клонирование</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="613"/>
        <source>Restoring</source>
        <translation>Восстановление</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="629"/>
        <source>Backup Failed</source>
        <translation>Резервное копирование Не удалось</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="635"/>
        <source>Clone Failed</source>
        <translation>Клонирование Не удалось</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="637"/>
        <source>Restore Failed</source>
        <translation>Восстановление Не удалось</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="642"/>
        <source>Retry</source>
        <translation>Повтор</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="655"/>
        <source>Backup Succeeded</source>
        <translation>Резервное копирование Успешно Завершено</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="656"/>
        <source>View Backup File</source>
        <translation>Просмотр Резервного Файла</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="669"/>
        <source>Restart</source>
        <translation>Перезапустить</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="795"/>
        <location filename="../src/widgets/mainwindow.cpp" line="813"/>
        <source>Loading</source>
        <translation>Загрузка</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="853"/>
        <source>Disk</source>
        <translation>Диск</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="855"/>
        <source>Partition</source>
        <translation>Раздел</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="247"/>
        <source>process &quot;%1 %2&quot; crashed</source>
        <translation>процесс &quot;%1 %2&quot; завершен аварийно</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="249"/>
        <source>Failed to perform process &quot;%1 %2&quot;, error: %3</source>
        <translation>Не удалось выполнить процесс &quot;%1 %2&quot;, ошибка: %3</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="256"/>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="271"/>
        <source>&quot;%1&quot; is not a disk device</source>
        <translation>&quot;%1&quot; не является дисковым устройством</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="298"/>
        <source>&quot;%1&quot; is busy</source>
        <translation>&quot;%1&quot; занят</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="325"/>
        <source>Failed to start &quot;%1 %2&quot;, error: %3</source>
        <translation>Не удалось запустить &quot;%1 %2&quot;, ошибка: %3</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="336"/>
        <source>Failed to open process, error: %1</source>
        <translation>Не удалось открыть процесс, ошибка: %1</translation>
    </message>
    <message>
        <location filename="../src/corelib/dfilediskinfo.cpp" line="178"/>
        <source>Failed to open file(%1), error: %2</source>
        <translation>Не удалось открыть файл(%1), ошибка: %2</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="208"/>
        <source>%1 d %2 h %3 m</source>
        <translation>%1 d %2 h %3 m</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="211"/>
        <source>%1 h %2 m</source>
        <translation>%1 h %2 m</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="214"/>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="216"/>
        <source>%1 s</source>
        <translation>%1 s</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="152"/>
        <source>Deepin Clone</source>
        <translation>Клонирование Deepin</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="153"/>
        <source>Deepin Clone is a backup and restore tool in deepin. It supports disk or partition clone, backup and restore, and other functions.</source>
        <translation>Клонирование Deepin - это инструмент резервного копирования и восстановления в Deepin. Он поддерживает клонирование дисков или разделов, резервное копирование и восстановление и другие функции.</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="850"/>
        <source>Partition &quot;%1&quot; not found</source>
        <translation>Раздел &quot;%1&quot; не найден</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="852"/>
        <source>Disk &quot;%1&quot; not found</source>
        <translation>Диск &quot;%1&quot; не найден</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="877"/>
        <location filename="../src/fixboot/bootdoctor.cpp" line="53"/>
        <location filename="../src/fixboot/bootdoctor.cpp" line="86"/>
        <location filename="../src/fixboot/bootdoctor.cpp" line="161"/>
        <source>Failed to mount partition &quot;%1&quot;</source>
        <translation>Ошибка монтирования раздела &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="173"/>
        <source>EFI partition not found</source>
        <translation>Раздел EFI не найден</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="177"/>
        <source>Unknown partition style</source>
        <translation>Неизвестный тип раздела</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="199"/>
        <source>Boot for install system failed</source>
        <translation>Загрузчик для установки системы не подходит</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="202"/>
        <source>Boot for update system failed</source>
        <translation>Загрузчик для обновления системы не подходит</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="266"/>
        <source>Boot for repair system failed</source>
        <translation>Загрузчик для восстановления системы не подходит</translation>
    </message>
</context>
<context>
    <name>SelectActionPage</name>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="75"/>
        <source>Select media</source>
        <translation>Выберите носитель</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="76"/>
        <source>Select operation for media</source>
        <translation>Выберите операцию для носителя</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="85"/>
        <source>Disk</source>
        <translation>Диск</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="94"/>
        <source>Partition</source>
        <translation>Раздел</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="119"/>
        <source>Clone Disk</source>
        <translation>Клонирование Диска</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="119"/>
        <source>Clone source disk to target disk</source>
        <translation>Клонировать исходный диск на диск назначения</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="122"/>
        <source>Disk to Image</source>
        <translation>Образ Диска</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="122"/>
        <source>Backup disk data to an image file</source>
        <translation>Резервное копирование данных на диск в файл образа</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="134"/>
        <source>Backup partition data to an image file</source>
        <translation>Резервное копирование данных раздела в файл образа</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="125"/>
        <source>Image to Disk</source>
        <translation>Образ Диска</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="125"/>
        <source>Restore image file to disk</source>
        <translation>Восстановить файл образа на диск</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="131"/>
        <source>Clone Partition</source>
        <translation>Клонирование Раздела</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="131"/>
        <source>Clone source partition to target partition</source>
        <translation>Клонировать исходный раздел в раздел назначения</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="134"/>
        <source>Partition to Image</source>
        <translation>Образ Раздела</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="137"/>
        <source>Image to Partition</source>
        <translation>Образ Раздела</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="137"/>
        <source>Restore image file to partition</source>
        <translation>Восстановить файл образа раздела</translation>
    </message>
</context>
<context>
    <name>SelectFilePage</name>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="322"/>
        <source>Select the source disk</source>
        <translation>Выберите исходный диск</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="323"/>
        <source>Select the target disk</source>
        <translation>Выберите диск назначения</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="337"/>
        <source>Select the source partition</source>
        <translation>Выберите исходный раздел</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="338"/>
        <source>Select the target partition</source>
        <translation>Выберите раздел назначения</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="366"/>
        <source>Select a disk to backup</source>
        <translation>Выберите диск для резервного копирования</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="374"/>
        <source>Select a partition to backup</source>
        <translation>Выберите раздел для резервного копирования</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="383"/>
        <source>Select storage location</source>
        <translation>Выберите место хранения</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="409"/>
        <source>Select a backup image file</source>
        <translation>Выберите файл образа резервной копии</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="412"/>
        <source>Select a disk to restore</source>
        <translation>Выберите диск для восстановления</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="414"/>
        <source>Select a partition to restore</source>
        <translation>Выберите раздел для восстановления</translation>
    </message>
</context>
<context>
    <name>SelectFileWidget</name>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="101"/>
        <source>Select storage location</source>
        <translation>Выберите место хранения</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="101"/>
        <source>Select image file</source>
        <translation>Выберите файл образа</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="223"/>
        <location filename="../src/widgets/selectfilepage.cpp" line="260"/>
        <source>Deepin Image File</source>
        <translation>Файл Образа Deepin</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="181"/>
        <source>Reselect image file</source>
        <translation>Повторите выбор файла образа</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="107"/>
        <source>Drag and drop the backup image file here</source>
        <translation>Перетащите файл резервной копии сюда</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="184"/>
        <source>Reselect storage location</source>
        <translation>Повторите выбор места хранения</translation>
    </message>
</context>
<context>
    <name>WorkingPage</name>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="44"/>
        <source>Task is ongoing, please wait......</source>
        <translation>Задача продолжается, пожалуйста подождите ...</translation>
    </message>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="61"/>
        <source>Progress: %1/%2</source>
        <translation>Прогресс: %1%2</translation>
    </message>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="62"/>
        <source>Time remaining: %1</source>
        <translation>Осталось времени: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="67"/>
        <source>Repairing system boot, please wait......</source>
        <translation>Восстановление системного загрузчика, пожалуйста ждите</translation>
    </message>
</context>
</TS>