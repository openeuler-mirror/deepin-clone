<?xml version="1.0" ?><!DOCTYPE TS><TS language="ko" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!message" line="0"/>
			<source>Authentication is required to run Deepin Clone</source>
			<translation>Deepin Clone을 실행하려면 인증이 필요합니다.</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!description" line="0"/>
			<source>Deepin Clone needs to do operations on block device, such as write and read, get info and etc.</source>
			<translation>Deepin Clone은 쓰기 및 읽기, 정보 가져오기 등과 같은 블록 작업에 대한 작업을 수행해야 합니다.</translation>
		</message>
	</context>
</TS>