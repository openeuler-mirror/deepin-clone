<?xml version="1.0" ?><!DOCTYPE TS><TS language="el" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!message" line="0"/>
			<source>Authentication is required to run Deepin Clone</source>
			<translation>Πιστοποίηση απαιτείται για να εκτελεστεί το Deepin Clone</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!description" line="0"/>
			<source>Deepin Clone needs to do operations on block device, such as write and read, get info and etc.</source>
			<translation>Το Deepin Clone χρειαεται να εκτελέσει λειτουργίες στο σύστημα, όπως εγγραφή και διάβασμα, για να καταχωρήσει τις πληροφορίες κτλ.</translation>
		</message>
	</context>
</TS>