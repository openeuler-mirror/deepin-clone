<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1"><context><name>desktop</name><message><location filename="Desktop Entry]GenericName" line="0"/><source>Clone</source><translation type="unfinished"/></message><message><location filename="Desktop Entry]Comment" line="0"/><source>Deepin Backup Restore Tool</source><translation type="unfinished"/></message><message><location filename="Desktop Entry]Name" line="0"/><source>Deepin Clone</source><translation type="unfinished"/></message></context></TS>
