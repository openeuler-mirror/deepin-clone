<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt" version="2.1">
<context>
    <name>CloneJob</name>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="146"/>
        <source>Writing data to %1 failed, expected write size: %2 — only %3 written, error: %4</source>
        <translation>Falhou a gravação de dados em %1, deveriam ter sido gravados: %2 — apenas %3 foram gravados, erro: %4</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="193"/>
        <source>%1 not exist</source>
        <translation>%1 não existe</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="207"/>
        <location filename="../src/corelib/clonejob.cpp" line="235"/>
        <source>%1 invalid or not exist</source>
        <translation>%1 inválido ou inexistente</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="219"/>
        <source>Disk only can be cloned to disk</source>
        <translation>Disco só pode ser clonado para disco</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="241"/>
        <source>%1 total capacity is less than maximum readable data on %2</source>
        <translation>A capacidade total do %1 é menor que o máximo de dados legíveis em %2</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="255"/>
        <source>Failed to change %1 size, please check the free space on target disk</source>
        <translation>Não foi possível alterar o tamanho %1, por favor, verifique o espaço livre no disco de destino</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="243"/>
        <location filename="../src/widgets/mainwindow.cpp" line="615"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="349"/>
        <source>Select Operation</source>
        <translation>Selecionar Operação</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="350"/>
        <source>Next</source>
        <translation>Seguinte</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="374"/>
        <location filename="../src/widgets/mainwindow.cpp" line="837"/>
        <source>Backup</source>
        <translation>Cópia de Segurança</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="376"/>
        <location filename="../src/widgets/mainwindow.cpp" line="839"/>
        <source>Clone</source>
        <translation>Clonar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="379"/>
        <location filename="../src/widgets/mainwindow.cpp" line="386"/>
        <source>Target disk will be permanently overwritten, please confirm to continue</source>
        <translation>O disco de destino será regravado permanentemente. Por favor, confirme para continuar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="381"/>
        <location filename="../src/widgets/mainwindow.cpp" line="388"/>
        <source>Target partition will be permanently overwritten, please confirm to continue</source>
        <translation>A partição de destino será regravada permanentemente. Por favor, confirme para continuar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="383"/>
        <location filename="../src/widgets/mainwindow.cpp" line="841"/>
        <source>Restore</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="400"/>
        <source>Please move image file to other location outside the disk to avoid data loss</source>
        <translation>Por favor, mova o ficheiro de imagem para outra localização fora do disco para evitar a perda de dados</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="402"/>
        <source>Please move image file to other location outside the partition to avoid data loss</source>
        <translation>Por favor, mova o ficheiro de imagem para outra localização fora da partição para evitar a perda de dados</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="415"/>
        <source>Storage location can not be in the disk to backup, please reselect</source>
        <translation>O local de armazenamento não pode ser no disco que vai ser colonado, por favor selecione de novo</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="417"/>
        <source>Storage location can not be in the partition to backup, please reselect</source>
        <translation>O local de armazenamento não pode ser na partição que vai ser colonada, por favor selecione de novo</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="492"/>
        <source>Proceed to clone?</source>
        <translation>Prosseguir para clonar?</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="495"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="496"/>
        <location filename="../src/widgets/mainwindow.cpp" line="547"/>
        <location filename="../src/widgets/mainwindow.cpp" line="665"/>
        <location filename="../src/widgets/mainwindow.cpp" line="788"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="512"/>
        <location filename="../src/widgets/mainwindow.cpp" line="593"/>
        <source>The selected storage location not found</source>
        <translation>Local de armazenamento selecionado não encontrado</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="652"/>
        <source>Task completed</source>
        <translation>Tarefa concluída</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="664"/>
        <source>Clone Successful</source>
        <translation>Clonagem bem sucedida</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="668"/>
        <source>Restore Succeessful</source>
        <translation>Restauro bem sucedido</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="736"/>
        <source>Failed to restart system</source>
        <translation>Não foi possível reiniciar o sistema</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="770"/>
        <source>Failed to restart &quot;Deepin Recovery&quot;</source>
        <translation>Não foi possível reiniciar o &quot;Deepin Recovery&quot;</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="542"/>
        <source>Restart to Continue</source>
        <translation>Reiniciar para Continuar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="239"/>
        <source>Restore boot</source>
        <translation>Restaurar arranque</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="436"/>
        <source>No enough total capacity in target disk, please select another one</source>
        <translation>Não há capacidade total suficiente no disco de destino, por favor, selecione outro</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="438"/>
        <source>No enough total capacity in target partition, please select another one</source>
        <translation>Não há capacidade total suficiente na partição de destino, por favor, selecione outra</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="463"/>
        <source>No enough total capacity, please select another disk</source>
        <translation>Não há capacidade total suficiente, por favor, selecione outro disco</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="493"/>
        <source>All data in the target disk (partition) will be formatted during cloning or restoring, which cannot be cancelled during the process.</source>
        <translation>Todos os dados no disco de destino (partição) serão formatados durante a clonagem ou o restauro, que não podem ser cancelados durante o processo.</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="526"/>
        <location filename="../src/widgets/mainwindow.cpp" line="581"/>
        <source>%1 not exist</source>
        <translation>%1 não existe</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="545"/>
        <source>&quot;%1&quot; is used, please restart and enter &quot;Deepin Recovery&quot; to continue</source>
        <translation>&quot;%1&quot; está a ser utilizado, por favor, reinicie e escreva &quot;Deepin Recovery&quot; para continuar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="550"/>
        <source>&quot;%1&quot; is used, please install &quot;Deepin Recovery&quot; to retry</source>
        <translation>&quot;%1&quot; está a ser utilizado, por favor, instale &quot;Deepin Recovery&quot; para tentar novamente</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="609"/>
        <source>Performing Backup</source>
        <translation>A efetuar a Cópia de Segurança</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="611"/>
        <source>Cloning</source>
        <translation>A Clonar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="613"/>
        <source>Restoring</source>
        <translation>A Restaurar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="629"/>
        <source>Backup Failed</source>
        <translation>Cópia de Segurança Falhou</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="635"/>
        <source>Clone Failed</source>
        <translation>Clonagem Falhou</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="637"/>
        <source>Restore Failed</source>
        <translation>Restauro Falhou</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="642"/>
        <source>Retry</source>
        <translation>Tentar Novamente</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="655"/>
        <source>Backup Succeeded</source>
        <translation>Cópia de segurança bem sucedida</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="656"/>
        <source>View Backup File</source>
        <translation>Ver Ficheiro da Cópia de Segurança</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="669"/>
        <source>Restart</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="795"/>
        <location filename="../src/widgets/mainwindow.cpp" line="813"/>
        <source>Loading</source>
        <translation>A carregar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="853"/>
        <source>Disk</source>
        <translation>Disco</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="855"/>
        <source>Partition</source>
        <translation>Partição</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="247"/>
        <source>process &quot;%1 %2&quot; crashed</source>
        <translation>o processo &quot;%1 %2&quot; crachou</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="249"/>
        <source>Failed to perform process &quot;%1 %2&quot;, error: %3</source>
        <translation>Falha no processo &quot;%1 %2&quot;, erro: %3</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="256"/>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="271"/>
        <source>&quot;%1&quot; is not a disk device</source>
        <translation>&quot;%1&quot; não é um disco</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="298"/>
        <source>&quot;%1&quot; is busy</source>
        <translation>&quot;%1&quot; está ocupado</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="325"/>
        <source>Failed to start &quot;%1 %2&quot;, error: %3</source>
        <translation>Falha ao iniciar &quot;%1 %2&quot;, erro: %3</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="336"/>
        <source>Failed to open process, error: %1</source>
        <translation>Falha ao abrir processo, erro: %1</translation>
    </message>
    <message>
        <location filename="../src/corelib/dfilediskinfo.cpp" line="178"/>
        <source>Failed to open file(%1), error: %2</source>
        <translation>Falha ao abrir ficheiro (%1), erro: %2</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="208"/>
        <source>%1 d %2 h %3 m</source>
        <translation>%1 d %2 h %3 m</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="211"/>
        <source>%1 h %2 m</source>
        <translation>%1 h %2 m</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="214"/>
        <source>%1 m</source>
        <translation>%1 h %2 m</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="216"/>
        <source>%1 s</source>
        <translation>%1 s</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="152"/>
        <source>Deepin Clone</source>
        <translation>Deepin Clone</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="153"/>
        <source>Deepin Clone is a backup and restore tool in deepin. It supports disk or partition clone, backup and restore, and other functions.</source>
        <translation>Deepin Clone é uma ferramenta para efetuar e restaurar cópias de segurança no deepin. Esta suporta a clonagem, cópia de segurança e restauro de discos ou partições e outras funções.</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="850"/>
        <source>Partition &quot;%1&quot; not found</source>
        <translation>Partição &quot;%1&quot; não encontrada</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="852"/>
        <source>Disk &quot;%1&quot; not found</source>
        <translation>Disco &quot;%1&quot; não econtrado</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="877"/>
        <location filename="../src/fixboot/bootdoctor.cpp" line="53"/>
        <location filename="../src/fixboot/bootdoctor.cpp" line="86"/>
        <location filename="../src/fixboot/bootdoctor.cpp" line="161"/>
        <source>Failed to mount partition &quot;%1&quot;</source>
        <translation>Não foi possível montar a partição &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="173"/>
        <source>EFI partition not found</source>
        <translation>Partição EFI não encontrada</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="177"/>
        <source>Unknown partition style</source>
        <translation>Formato da tabela de partição desconhecido</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="199"/>
        <source>Boot for install system failed</source>
        <translation>Falhou o arranque para a instalação do sistema</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="202"/>
        <source>Boot for update system failed</source>
        <translation>Falhou o arranque para a atualização de sistema</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="266"/>
        <source>Boot for repair system failed</source>
        <translation>Falhou o arranque para a reparação do sistema</translation>
    </message>
</context>
<context>
    <name>SelectActionPage</name>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="75"/>
        <source>Select media</source>
        <translation>Selecionar unidade</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="76"/>
        <source>Select operation for media</source>
        <translation>Selecionar a operação para a unidade</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="85"/>
        <source>Disk</source>
        <translation>Disco</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="94"/>
        <source>Partition</source>
        <translation>Partição</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="119"/>
        <source>Clone Disk</source>
        <translation>Clonar Disco</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="119"/>
        <source>Clone source disk to target disk</source>
        <translation>Clonar um disco de origem para um disco de destino</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="122"/>
        <source>Disk to Image</source>
        <translation>Disco para Imagem</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="122"/>
        <source>Backup disk data to an image file</source>
        <translation>Cópia de segurança dos dados do disco para um ficheiro de imagem</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="134"/>
        <source>Backup partition data to an image file</source>
        <translation>Cópia de segurança dos dados da partição num ficheiro de imagem</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="125"/>
        <source>Image to Disk</source>
        <translation>Imagem para Disco</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="125"/>
        <source>Restore image file to disk</source>
        <translation>Restaura um ficheiro de imagem para disco</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="131"/>
        <source>Clone Partition</source>
        <translation>Clonar Partição</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="131"/>
        <source>Clone source partition to target partition</source>
        <translation>Clonar partição fonte para partição de destino</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="134"/>
        <source>Partition to Image</source>
        <translation>Partição para Imagem</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="137"/>
        <source>Image to Partition</source>
        <translation>Imagem para Partição</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="137"/>
        <source>Restore image file to partition</source>
        <translation>Restaurar um ficheiro de imagem para partição</translation>
    </message>
</context>
<context>
    <name>SelectFilePage</name>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="322"/>
        <source>Select the source disk</source>
        <translation>Selecione o disco fonte</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="323"/>
        <source>Select the target disk</source>
        <translation>Selecione o disco de destino</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="337"/>
        <source>Select the source partition</source>
        <translation>Selecione a partição fonte</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="338"/>
        <source>Select the target partition</source>
        <translation>Selecione a partição de destino</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="366"/>
        <source>Select a disk to backup</source>
        <translation>Selecione um disco para o copiar</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="374"/>
        <source>Select a partition to backup</source>
        <translation>Selecione uma partição para a copiar</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="383"/>
        <source>Select storage location</source>
        <translation>Selecione a localização de armazenamento</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="409"/>
        <source>Select a backup image file</source>
        <translation>Selecione o ficheiro de imagem da cópia de segurança</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="412"/>
        <source>Select a disk to restore</source>
        <translation>Selecione um disco para o restaurar</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="414"/>
        <source>Select a partition to restore</source>
        <translation>Selecione uma partição para a restaurar</translation>
    </message>
</context>
<context>
    <name>SelectFileWidget</name>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="101"/>
        <source>Select storage location</source>
        <translation>Selecione a localização de armazenamento</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="101"/>
        <source>Select image file</source>
        <translation>Selecione o ficheiro imagem</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="223"/>
        <location filename="../src/widgets/selectfilepage.cpp" line="260"/>
        <source>Deepin Image File</source>
        <translation>Ficheiro de Imagem Deepin</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="181"/>
        <source>Reselect image file</source>
        <translation>Volte a selecionar o ficheiro de imagem</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="107"/>
        <source>Drag and drop the backup image file here</source>
        <translation>Arraste e largue aqui o ficheiro de imagem da cópia de segurança</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="184"/>
        <source>Reselect storage location</source>
        <translation>Volte a selecionar a localização de armazenamento</translation>
    </message>
</context>
<context>
    <name>WorkingPage</name>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="44"/>
        <source>Task is ongoing, please wait......</source>
        <translation>Tarefa em progresso, por favor, aguarde......</translation>
    </message>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="61"/>
        <source>Progress: %1/%2</source>
        <translation>Progresso: %1/%2</translation>
    </message>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="62"/>
        <source>Time remaining: %1</source>
        <translation>Tempo restante: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="67"/>
        <source>Repairing system boot, please wait......</source>
        <translation>A reparar o arranque do sistema, por favor, aguarde...</translation>
    </message>
</context>
</TS>