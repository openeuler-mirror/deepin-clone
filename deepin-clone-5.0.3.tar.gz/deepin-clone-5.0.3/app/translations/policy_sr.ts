<?xml version="1.0" ?><!DOCTYPE TS><TS language="sr" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!message" line="0"/>
			<source>Authentication is required to run Deepin Clone</source>
			<translation>Аутентификација је неопходна за покретање Дипин Клонирања</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!description" line="0"/>
			<source>Deepin Clone needs to do operations on block device, such as write and read, get info and etc.</source>
			<translation>Дипин Клонирање извршава операције на блок уређајима, као што су уписивање и читање, прикупљање података итд.</translation>
		</message>
	</context>
</TS>