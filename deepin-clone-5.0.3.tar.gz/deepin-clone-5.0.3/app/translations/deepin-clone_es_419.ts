<?xml version="1.0" ?><!DOCTYPE TS><TS language="es_419" version="2.1">
<context>
    <name>CloneJob</name>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="146"/>
        <source>Writing data to %1 failed, expected write size: %2 — only %3 written, error: %4</source>
        <translation>Error al escribir los datos en %1, Tamaño esperado de escritura: %2 —  Solo %3 fueron escritos, Error: %4    </translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="193"/>
        <source>%1 not exist</source>
        <translation>%1 no existe</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="207"/>
        <location filename="../src/corelib/clonejob.cpp" line="235"/>
        <source>%1 invalid or not exist</source>
        <translation>%1 inválido o no existe</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="219"/>
        <source>Disk only can be cloned to disk</source>
        <translation>El disco sólo puede ser clonado en el disco</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="241"/>
        <source>%1 total capacity is less than maximum readable data on %2</source>
        <translation>%1 capacidad total es menor que los datos legibles máximos en %2</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="255"/>
        <source>Failed to change %1 size, please check the free space on target disk</source>
        <translation>Error al cambiar tamaño de %1, verifique el espacio libre en el disco de destino</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="243"/>
        <location filename="../src/widgets/mainwindow.cpp" line="615"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="349"/>
        <source>Select Operation</source>
        <translation>Seleccione una operación</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="350"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="374"/>
        <location filename="../src/widgets/mainwindow.cpp" line="837"/>
        <source>Backup</source>
        <translation>Copia de seguridad</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="376"/>
        <location filename="../src/widgets/mainwindow.cpp" line="839"/>
        <source>Clone</source>
        <translation>Clonar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="379"/>
        <location filename="../src/widgets/mainwindow.cpp" line="386"/>
        <source>Target disk will be permanently overwritten, please confirm to continue</source>
        <translation>El disco de destino se sobrescribirá permanentemente, confirme para continuar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="381"/>
        <location filename="../src/widgets/mainwindow.cpp" line="388"/>
        <source>Target partition will be permanently overwritten, please confirm to continue</source>
        <translation>La partición de destino se sobrescribirá permanentemente, confirme para continuar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="383"/>
        <location filename="../src/widgets/mainwindow.cpp" line="841"/>
        <source>Restore</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="400"/>
        <source>Please move image file to other location outside the disk to avoid data loss</source>
        <translation>Por favor mueva el archivo de imagen a otra ubicación fuera del disco para evitar la pérdida de datos</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="402"/>
        <source>Please move image file to other location outside the partition to avoid data loss</source>
        <translation>Por favor mueva el archivo de imagen a otra ubicación fuera de la partición para evitar la pérdida de datos</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="415"/>
        <source>Storage location can not be in the disk to backup, please reselect</source>
        <translation>No es posible usar el disco como localización para el respaldo, por favor vuelva a seleccionar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="417"/>
        <source>Storage location can not be in the partition to backup, please reselect</source>
        <translation>No es posible usar la partición como localización para el respaldo, por favor vuelva a seleccionar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="492"/>
        <source>Proceed to clone?</source>
        <translation>¿Desea iniciar el proceso de clonado?</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="495"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="496"/>
        <location filename="../src/widgets/mainwindow.cpp" line="547"/>
        <location filename="../src/widgets/mainwindow.cpp" line="665"/>
        <location filename="../src/widgets/mainwindow.cpp" line="788"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="512"/>
        <location filename="../src/widgets/mainwindow.cpp" line="593"/>
        <source>The selected storage location not found</source>
        <translation>La ubicación de almacenamiento seleccionada no fue encontrada</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="652"/>
        <source>Task completed</source>
        <translation>Tarea completada</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="664"/>
        <source>Clone Successful</source>
        <translation>Clonado Exitoso</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="668"/>
        <source>Restore Succeessful</source>
        <translation>Restauración Exitosa</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="736"/>
        <source>Failed to restart system</source>
        <translation>Error al reiniciar el sistema</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="770"/>
        <source>Failed to restart &quot;Deepin Recovery&quot;</source>
        <translation>Error al reiniciar &quot;Recuperación de Deepin&quot;</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="542"/>
        <source>Restart to Continue</source>
        <translation>Reiniciar para continuar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="239"/>
        <source>Restore boot</source>
        <translation>Restaurar arranque</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="436"/>
        <source>No enough total capacity in target disk, please select another one</source>
        <translation>No hay capacidad suficiente en el disco de destino, por favor seleccione otra unidad</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="438"/>
        <source>No enough total capacity in target partition, please select another one</source>
        <translation>No hay capacidad suficiente en la partición de destino, por favor seleccione otra.   </translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="463"/>
        <source>No enough total capacity, please select another disk</source>
        <translation>No hay capacidad suficiente, por favor seleccione otro disco</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="493"/>
        <source>All data in the target disk (partition) will be formatted during cloning or restoring, which cannot be cancelled during the process.</source>
        <translation>Todos los datos en el disco de destino (partición) se formatearán durante la clonación o restauración, que no puede ser cancelada durante el proceso.</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="526"/>
        <location filename="../src/widgets/mainwindow.cpp" line="581"/>
        <source>%1 not exist</source>
        <translation>%1 no existe</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="545"/>
        <source>&quot;%1&quot; is used, please restart and enter &quot;Deepin Recovery&quot; to continue</source>
        <translation>&quot;%1&quot; en uso, reinicie e ingrese &quot;Recuperación de Deepin&quot; para continuar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="550"/>
        <source>&quot;%1&quot; is used, please install &quot;Deepin Recovery&quot; to retry</source>
        <translation>&quot;%1&quot; en uso, por favor, instale &quot;Recuperación de Deepin&quot; para reintentar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="609"/>
        <source>Performing Backup</source>
        <translation>Realización de copia de seguridad</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="611"/>
        <source>Cloning</source>
        <translation>Clonando</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="613"/>
        <source>Restoring</source>
        <translation>Restaurando</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="629"/>
        <source>Backup Failed</source>
        <translation>Copia de seguridad fallida</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="635"/>
        <source>Clone Failed</source>
        <translation>Clonación fallida</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="637"/>
        <source>Restore Failed</source>
        <translation>Restauración fallida</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="642"/>
        <source>Retry</source>
        <translation>Reintentar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="655"/>
        <source>Backup Succeeded</source>
        <translation>Copia de seguridad con éxito</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="656"/>
        <source>View Backup File</source>
        <translation>Ver archivo de copia de seguridad</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="669"/>
        <source>Restart</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="795"/>
        <location filename="../src/widgets/mainwindow.cpp" line="813"/>
        <source>Loading</source>
        <translation>Cargando</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="853"/>
        <source>Disk</source>
        <translation>Disco</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="855"/>
        <source>Partition</source>
        <translation>Partición</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="247"/>
        <source>process &quot;%1 %2&quot; crashed</source>
        <translation>proceso &quot;%1 %2&quot; interrumpido</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="249"/>
        <source>Failed to perform process &quot;%1 %2&quot;, error: %3</source>
        <translation>Error al realizar el proceso &quot;%1 %2&quot;, error: %3</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="256"/>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="271"/>
        <source>&quot;%1&quot; is not a disk device</source>
        <translation>&quot;%1&quot; no es un dispositivo de disco</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="298"/>
        <source>&quot;%1&quot; is busy</source>
        <translation>&quot;%1&quot; está ocupado</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="325"/>
        <source>Failed to start &quot;%1 %2&quot;, error: %3</source>
        <translation>Error al iniciar &quot;%1 %2&quot;, error: %3</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="336"/>
        <source>Failed to open process, error: %1</source>
        <translation>Error al abrir el proceso, error: %1</translation>
    </message>
    <message>
        <location filename="../src/corelib/dfilediskinfo.cpp" line="178"/>
        <source>Failed to open file(%1), error: %2</source>
        <translation>Error al abrir el archivo (%1), error: %2</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="208"/>
        <source>%1 d %2 h %3 m</source>
        <translation>%1 d %2 h %3 m</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="211"/>
        <source>%1 h %2 m</source>
        <translation>%1 h %2 m</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="214"/>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="216"/>
        <source>%1 s</source>
        <translation>%1 s</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="152"/>
        <source>Deepin Clone</source>
        <translation>Deepin Clone</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="153"/>
        <source>Deepin Clone is a backup and restore tool in deepin. It supports disk or partition clone, backup and restore, and other functions.</source>
        <translation>Deepin Clone es una herramienta de respaldo y restauración. La misma soporta clonado de discos o particiones, respaldo, restauración y otras funcionalidades. </translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="850"/>
        <source>Partition &quot;%1&quot; not found</source>
        <translation>Partición &quot;%1&quot; no encontrada</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="852"/>
        <source>Disk &quot;%1&quot; not found</source>
        <translation>Disco&quot;%1&quot; no encontrado</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="877"/>
        <location filename="../src/fixboot/bootdoctor.cpp" line="53"/>
        <location filename="../src/fixboot/bootdoctor.cpp" line="86"/>
        <location filename="../src/fixboot/bootdoctor.cpp" line="161"/>
        <source>Failed to mount partition &quot;%1&quot;</source>
        <translation>Error al montar la partición &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="173"/>
        <source>EFI partition not found</source>
        <translation>Partición EFI no encontrada</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="177"/>
        <source>Unknown partition style</source>
        <translation>Tipo de partición desconocida</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="199"/>
        <source>Boot for install system failed</source>
        <translation>El arranque para instalar el sistema falló</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="202"/>
        <source>Boot for update system failed</source>
        <translation>El arranque para actualizar el sistema falló</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="266"/>
        <source>Boot for repair system failed</source>
        <translation>El arranque para reparar el sistema falló</translation>
    </message>
</context>
<context>
    <name>SelectActionPage</name>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="75"/>
        <source>Select media</source>
        <translation>Seleccionar medio</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="76"/>
        <source>Select operation for media</source>
        <translation>Seleccione la operación para los medios</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="85"/>
        <source>Disk</source>
        <translation>Disco</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="94"/>
        <source>Partition</source>
        <translation>Partición </translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="119"/>
        <source>Clone Disk</source>
        <translation>Clonar disco</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="119"/>
        <source>Clone source disk to target disk</source>
        <translation>Clona el disco de origen al disco de destino</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="122"/>
        <source>Disk to Image</source>
        <translation>Disco a imagen</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="122"/>
        <source>Backup disk data to an image file</source>
        <translation>Respaldar los datos del disco a un archivo de imagen</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="134"/>
        <source>Backup partition data to an image file</source>
        <translation>Repaldar los datos del disco a un archivo de imagen</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="125"/>
        <source>Image to Disk</source>
        <translation>Imagen a disco</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="125"/>
        <source>Restore image file to disk</source>
        <translation>Restaura archivo de imagen a disco</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="131"/>
        <source>Clone Partition</source>
        <translation>Clonar partición</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="131"/>
        <source>Clone source partition to target partition</source>
        <translation>Clona la partición de origen a la partición de destino</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="134"/>
        <source>Partition to Image</source>
        <translation>Partición a Imagen</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="137"/>
        <source>Image to Partition</source>
        <translation>Imagen a Partición</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="137"/>
        <source>Restore image file to partition</source>
        <translation>Restaura archivo de imagen a partición</translation>
    </message>
</context>
<context>
    <name>SelectFilePage</name>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="322"/>
        <source>Select the source disk</source>
        <translation>Seleccione el disco de origen</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="323"/>
        <source>Select the target disk</source>
        <translation>Seleccione el disco de destino</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="337"/>
        <source>Select the source partition</source>
        <translation>Seleccione la partición de origen</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="338"/>
        <source>Select the target partition</source>
        <translation>Seleccione la partición de destino</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="366"/>
        <source>Select a disk to backup</source>
        <translation>Seleccionar disco a respaldar</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="374"/>
        <source>Select a partition to backup</source>
        <translation>Seleccionar partición a respaldar</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="383"/>
        <source>Select storage location</source>
        <translation>Seleccionar ubicación de almacenamiento</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="409"/>
        <source>Select a backup image file</source>
        <translation>Seleccione un archivo de imagen de copia de seguridad</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="412"/>
        <source>Select a disk to restore</source>
        <translation>Seleccionar disco a restaurar</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="414"/>
        <source>Select a partition to restore</source>
        <translation>Seleccionar partición a restaurar</translation>
    </message>
</context>
<context>
    <name>SelectFileWidget</name>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="101"/>
        <source>Select storage location</source>
        <translation>Seleccionar ubicación de almacenamiento</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="101"/>
        <source>Select image file</source>
        <translation>Seleccionar archivo de imagen</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="223"/>
        <location filename="../src/widgets/selectfilepage.cpp" line="260"/>
        <source>Deepin Image File</source>
        <translation>Archivo de imagen Deepin</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="181"/>
        <source>Reselect image file</source>
        <translation>Reseleccionar archivo de imagen</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="107"/>
        <source>Drag and drop the backup image file here</source>
        <translation>Arrastra y suelta aquí el archivo de respaldo.</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="184"/>
        <source>Reselect storage location</source>
        <translation>Reseleccionar ubicación de almacenamiento</translation>
    </message>
</context>
<context>
    <name>WorkingPage</name>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="44"/>
        <source>Task is ongoing, please wait......</source>
        <translation>Tarea en curso, por favor espere...</translation>
    </message>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="61"/>
        <source>Progress: %1/%2</source>
        <translation>Progreso: %1/%2</translation>
    </message>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="62"/>
        <source>Time remaining: %1</source>
        <translation>Tiempo restante %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="67"/>
        <source>Repairing system boot, please wait......</source>
        <translation>Reparando sistema de arranque, espere...</translation>
    </message>
</context>
</TS>