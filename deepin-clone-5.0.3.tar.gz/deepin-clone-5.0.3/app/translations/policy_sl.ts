<?xml version="1.0" ?><!DOCTYPE TS><TS language="sl" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!message" line="0"/>
			<source>Authentication is required to run Deepin Clone</source>
			<translation type="unfinished"/>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!description" line="0"/>
			<source>Deepin Clone needs to do operations on block device, such as write and read, get info and etc.</source>
			<translation>Klonirnik Deepin mora na napravini datoteki izvajati nekatere operacije, kot so zapisovanje, branje, pridobivanje informacij itd.</translation>
		</message>
	</context>
</TS>