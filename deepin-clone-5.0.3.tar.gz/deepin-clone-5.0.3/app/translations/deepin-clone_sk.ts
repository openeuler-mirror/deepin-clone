<?xml version="1.0" ?><!DOCTYPE TS><TS language="sk" version="2.1">
<context>
    <name>CloneJob</name>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="146"/>
        <source>Writing data to %1 failed, expected write size: %2 — only %3 written, error: %4</source>
        <translation>Zápis údajov na %1 zlyhal, mali by byť zapísané údaje o veľkosti %2, ale v skutočnosti %3 zapísal chybu: %4</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="193"/>
        <source>%1 not exist</source>
        <translation>%1 neexistuje</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="207"/>
        <location filename="../src/corelib/clonejob.cpp" line="235"/>
        <source>%1 invalid or not exist</source>
        <translation>%1 je neplatný alebo neexistuje</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="219"/>
        <source>Disk only can be cloned to disk</source>
        <translation>Len disk možno klonovať na disk</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="241"/>
        <source>%1 total capacity is less than maximum readable data on %2</source>
        <translation>Celková kapacita %1 je menšia ako maximálne čitateľné data %2</translation>
    </message>
    <message>
        <location filename="../src/corelib/clonejob.cpp" line="255"/>
        <source>Failed to change %1 size, please check the free space on target disk</source>
        <translation>Nepodarilo sa zmeniť veľkosť %1, skontrolujte voľný priestor na cieľovom disku</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="243"/>
        <location filename="../src/widgets/mainwindow.cpp" line="615"/>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="349"/>
        <source>Select Operation</source>
        <translation>Výber operácie</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="350"/>
        <source>Next</source>
        <translation>Ďalej</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="374"/>
        <location filename="../src/widgets/mainwindow.cpp" line="837"/>
        <source>Backup</source>
        <translation>Záloha</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="376"/>
        <location filename="../src/widgets/mainwindow.cpp" line="839"/>
        <source>Clone</source>
        <translation>Klonovanie</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="379"/>
        <location filename="../src/widgets/mainwindow.cpp" line="386"/>
        <source>Target disk will be permanently overwritten, please confirm to continue</source>
        <translation>Cieľový disk bude natrvalo prepísaný, potvrďte pokračovanie</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="381"/>
        <location filename="../src/widgets/mainwindow.cpp" line="388"/>
        <source>Target partition will be permanently overwritten, please confirm to continue</source>
        <translation>Cieľový oddiel bude natrvalo prepísaný, potvrďte pokračovanie</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="383"/>
        <location filename="../src/widgets/mainwindow.cpp" line="841"/>
        <source>Restore</source>
        <translation>Obnova</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="400"/>
        <source>Please move image file to other location outside the disk to avoid data loss</source>
        <translation>Presuňte súbor obrazu na iné miesto mimo disku, aby ste predišli strate údajov</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="402"/>
        <source>Please move image file to other location outside the partition to avoid data loss</source>
        <translation>Premiestnite súbor obrazu na iné miesto mimo oddiel, aby ste predišli strate údajov</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="415"/>
        <source>Storage location can not be in the disk to backup, please reselect</source>
        <translation>Miesto uloženia nemôže byť na disku na zálohovanie, prosím znova vyberte</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="417"/>
        <source>Storage location can not be in the partition to backup, please reselect</source>
        <translation>Miesto uloženia nemôže byť v oddieli na zálohovanie, prosím znova vyberte</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="492"/>
        <source>Proceed to clone?</source>
        <translation>Spustiť klonovanie?</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="495"/>
        <source>Warning</source>
        <translation>Varovanie</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="496"/>
        <location filename="../src/widgets/mainwindow.cpp" line="547"/>
        <location filename="../src/widgets/mainwindow.cpp" line="665"/>
        <location filename="../src/widgets/mainwindow.cpp" line="788"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="512"/>
        <location filename="../src/widgets/mainwindow.cpp" line="593"/>
        <source>The selected storage location not found</source>
        <translation>Vybrané miesto uloženia sa nenašlo</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="652"/>
        <source>Task completed</source>
        <translation>Úloha bola dokončená</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="664"/>
        <source>Clone Successful</source>
        <translation>Klon úspešný</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="668"/>
        <source>Restore Succeessful</source>
        <translation>Obnova úspešná</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="736"/>
        <source>Failed to restart system</source>
        <translation>Nepodarilo sa reštartovať systém</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="770"/>
        <source>Failed to restart &quot;Deepin Recovery&quot;</source>
        <translation>Nepodarilo sa reštartovať program &quot;Deepin Oprava&quot;</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="542"/>
        <source>Restart to Continue</source>
        <translation>Reštartujte a pokračujte</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="239"/>
        <source>Restore boot</source>
        <translation>Obnova bootovania</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="436"/>
        <source>No enough total capacity in target disk, please select another one</source>
        <translation>V cieľovom disku nie je dostatočná celková kapacita, vyberte iný</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="438"/>
        <source>No enough total capacity in target partition, please select another one</source>
        <translation>V cieľovom oddieli nie je dostatočná celková kapacita, vyberte iný</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="463"/>
        <source>No enough total capacity, please select another disk</source>
        <translation>Nedostatok celkovej kapacity, vyberte iný disk</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="493"/>
        <source>All data in the target disk (partition) will be formatted during cloning or restoring, which cannot be cancelled during the process.</source>
        <translation>Všetky dáta v cieľovom disku (oddiely) budú formátované počas klonovania alebo obnovenia disku, ktoré počas procesu nemožno zrušiť.</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="526"/>
        <location filename="../src/widgets/mainwindow.cpp" line="581"/>
        <source>%1 not exist</source>
        <translation>%1 neexistuje</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="545"/>
        <source>&quot;%1&quot; is used, please restart and enter &quot;Deepin Recovery&quot; to continue</source>
        <translation>&quot;%1&quot; sa používa, prosím reštartujte a spustite &quot;Deepin Oprava&quot; pre pokračovanie</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="550"/>
        <source>&quot;%1&quot; is used, please install &quot;Deepin Recovery&quot; to retry</source>
        <translation>&quot;%1&quot; sa používa, prosím nainštalujte &quot;Deepin Oprava&quot; a skúste znova</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="609"/>
        <source>Performing Backup</source>
        <translation>Vykonávanie zálohovania</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="611"/>
        <source>Cloning</source>
        <translation>Klonujem</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="613"/>
        <source>Restoring</source>
        <translation>Obnovujem</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="629"/>
        <source>Backup Failed</source>
        <translation>Zálohovanie zlyhalo</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="635"/>
        <source>Clone Failed</source>
        <translation>Klonovanie zlyhalo</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="637"/>
        <source>Restore Failed</source>
        <translation>Obnovenie zlyhalo</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="642"/>
        <source>Retry</source>
        <translation>Skúsiť znova</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="655"/>
        <source>Backup Succeeded</source>
        <translation>Záloha úspešná</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="656"/>
        <source>View Backup File</source>
        <translation>Zobraziť súbor zálohy</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="669"/>
        <source>Restart</source>
        <translation>Reštart</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="795"/>
        <location filename="../src/widgets/mainwindow.cpp" line="813"/>
        <source>Loading</source>
        <translation>Nahrávam</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="853"/>
        <source>Disk</source>
        <translation>Disk</translation>
    </message>
    <message>
        <location filename="../src/widgets/mainwindow.cpp" line="855"/>
        <source>Partition</source>
        <translation>Oddiel</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="247"/>
        <source>process &quot;%1 %2&quot; crashed</source>
        <translation>proces &quot;%1 %2&quot; havaroval</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="249"/>
        <source>Failed to perform process &quot;%1 %2&quot;, error: %3</source>
        <translation>Nepodarilo sa vykonať proces &quot;%1 %2&quot;, chyba: %3</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="256"/>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="271"/>
        <source>&quot;%1&quot; is not a disk device</source>
        <translation>&quot;%1&quot; nie je diskové zariadenie</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="298"/>
        <source>&quot;%1&quot; is busy</source>
        <translation>&quot;%1&quot; je zaneprázdnený</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="325"/>
        <source>Failed to start &quot;%1 %2&quot;, error: %3</source>
        <translation>Nepodarilo sa spustiť &quot;%1 %2&quot;, chyba: %3</translation>
    </message>
    <message>
        <location filename="../src/corelib/ddevicediskinfo.cpp" line="336"/>
        <source>Failed to open process, error: %1</source>
        <translation>Nepodarilo sa otvoriť proces, chyba: %1</translation>
    </message>
    <message>
        <location filename="../src/corelib/dfilediskinfo.cpp" line="178"/>
        <source>Failed to open file(%1), error: %2</source>
        <translation>Nepodarilo sa otvoriť súbor (%1), chyba: %2</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="208"/>
        <source>%1 d %2 h %3 m</source>
        <translation>%1 d %2 h %3 m</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="211"/>
        <source>%1 h %2 m</source>
        <translation>%1 h %2 m</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="214"/>
        <source>%1 m</source>
        <translation>%1 m</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="216"/>
        <source>%1 s</source>
        <translation>%1 s</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="152"/>
        <source>Deepin Clone</source>
        <translation>Deepin Klonovanie</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="153"/>
        <source>Deepin Clone is a backup and restore tool in deepin. It supports disk or partition clone, backup and restore, and other functions.</source>
        <translation>Deepin Klonovanie je nástroj na zálohovanie a obnovu v deepine. Podporuje klonovanie, zálohovanie a obnovu disku alebo diskových oddielov a ďalšie funkcie.</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="850"/>
        <source>Partition &quot;%1&quot; not found</source>
        <translation>Oddiel &quot;%1&quot; sa nenašiel</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="852"/>
        <source>Disk &quot;%1&quot; not found</source>
        <translation>Disk &quot;%1&quot; sa nenašiel</translation>
    </message>
    <message>
        <location filename="../src/corelib/helper.cpp" line="877"/>
        <location filename="../src/fixboot/bootdoctor.cpp" line="53"/>
        <location filename="../src/fixboot/bootdoctor.cpp" line="86"/>
        <location filename="../src/fixboot/bootdoctor.cpp" line="161"/>
        <source>Failed to mount partition &quot;%1&quot;</source>
        <translation>Nepodarilo sa pripojiť oddiel &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="173"/>
        <source>EFI partition not found</source>
        <translation>EFI oddiel sa nenašiel</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="177"/>
        <source>Unknown partition style</source>
        <translation>Neznámy formát tabuľky oddielu</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="199"/>
        <source>Boot for install system failed</source>
        <translation>Boot pre inštalačný systém zlyhal</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="202"/>
        <source>Boot for update system failed</source>
        <translation>Boot pre systém aktualizácie zlyhal</translation>
    </message>
    <message>
        <location filename="../src/fixboot/bootdoctor.cpp" line="266"/>
        <source>Boot for repair system failed</source>
        <translation>Boot pre systém opravy zlyhal</translation>
    </message>
</context>
<context>
    <name>SelectActionPage</name>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="75"/>
        <source>Select media</source>
        <translation>Výber médiá</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="76"/>
        <source>Select operation for media</source>
        <translation>Výber operácie pre médium</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="85"/>
        <source>Disk</source>
        <translation>Disk</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="94"/>
        <source>Partition</source>
        <translation>Oddiel</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="119"/>
        <source>Clone Disk</source>
        <translation>Klonovanie disku</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="119"/>
        <source>Clone source disk to target disk</source>
        <translation>Klon zdrojového disku na cieľový disk</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="122"/>
        <source>Disk to Image</source>
        <translation>Disk na obraz</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="122"/>
        <source>Backup disk data to an image file</source>
        <translation>Zálohovanie dát disku do súboru obrazu</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="134"/>
        <source>Backup partition data to an image file</source>
        <translation>Zálohovanie dát oddielu do súboru obrazu</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="125"/>
        <source>Image to Disk</source>
        <translation>Obraz na disk</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="125"/>
        <source>Restore image file to disk</source>
        <translation>Obnova súboru obrazu na disk</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="131"/>
        <source>Clone Partition</source>
        <translation>Klon oddielu</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="131"/>
        <source>Clone source partition to target partition</source>
        <translation>Klon zdrojového oddielu do cieľového oddielu</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="134"/>
        <source>Partition to Image</source>
        <translation>Oddiel na obraz</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="137"/>
        <source>Image to Partition</source>
        <translation>Obraz na oddiel</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectactionpage.cpp" line="137"/>
        <source>Restore image file to partition</source>
        <translation>Obnoviť súbor obrazu na oddiel</translation>
    </message>
</context>
<context>
    <name>SelectFilePage</name>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="322"/>
        <source>Select the source disk</source>
        <translation>Vyberte zdrojový disk</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="323"/>
        <source>Select the target disk</source>
        <translation>Vyberte cieľový disk</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="337"/>
        <source>Select the source partition</source>
        <translation>Vyberte zdrojový oddiel</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="338"/>
        <source>Select the target partition</source>
        <translation>Vyberte cieľový oddiel</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="366"/>
        <source>Select a disk to backup</source>
        <translation>Vyberte disk na zálohovanie</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="374"/>
        <source>Select a partition to backup</source>
        <translation>Vyberte oblasť na zálohovanie</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="383"/>
        <source>Select storage location</source>
        <translation>Vyberte miesto uloženia</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="409"/>
        <source>Select a backup image file</source>
        <translation>Vyberte súbor s obrazom zálohy</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="412"/>
        <source>Select a disk to restore</source>
        <translation>Vyberte disk, ktorý chcete obnoviť</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="414"/>
        <source>Select a partition to restore</source>
        <translation>Vyberte oblasť, ktorú chcete obnoviť</translation>
    </message>
</context>
<context>
    <name>SelectFileWidget</name>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="101"/>
        <source>Select storage location</source>
        <translation>Vyberte miesto uloženia</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="101"/>
        <source>Select image file</source>
        <translation>Vyberte súbor obrazu</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="223"/>
        <location filename="../src/widgets/selectfilepage.cpp" line="260"/>
        <source>Deepin Image File</source>
        <translation>Deepin súbor obrazu</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="181"/>
        <source>Reselect image file</source>
        <translation>Znova vyberte obraz</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="107"/>
        <source>Drag and drop the backup image file here</source>
        <translation>Presuňte súbor obrazu tu</translation>
    </message>
    <message>
        <location filename="../src/widgets/selectfilepage.cpp" line="184"/>
        <source>Reselect storage location</source>
        <translation>Znova vyberte miesto uloženia</translation>
    </message>
</context>
<context>
    <name>WorkingPage</name>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="44"/>
        <source>Task is ongoing, please wait......</source>
        <translation>Úloha prebieha, čakajte prosím......</translation>
    </message>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="61"/>
        <source>Progress: %1/%2</source>
        <translation>Priebeh: %1/%2</translation>
    </message>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="62"/>
        <source>Time remaining: %1</source>
        <translation>Zostávajúci čas: %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/workingpage.cpp" line="67"/>
        <source>Repairing system boot, please wait......</source>
        <translation>Oprava boot systému, čakajte......</translation>
    </message>
</context>
</TS>