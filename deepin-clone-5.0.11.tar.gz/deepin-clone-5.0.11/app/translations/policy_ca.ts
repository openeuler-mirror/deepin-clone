<?xml version="1.0" ?><!DOCTYPE TS><TS language="ca" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!message" line="0"/>
			<source>Authentication is required to run Deepin Clone</source>
			<translation>Cal autenticació per executar el Clon del Deepin.</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!description" line="0"/>
			<source>Deepin Clone needs to do operations on block device, such as write and read, get info and etc.</source>
			<translation>El Clon del Deepin necessita fer operacions al dispositiu de bloc, com ara llegir i escriure, obtenir informació, etc.</translation>
		</message>
	</context>
</TS>