<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!message" line="0"/>
			<source>Authentication is required to run Deepin Clone</source>
			<translation>使用深度备份还原工具需要认证</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!description" line="0"/>
			<source>Deepin Clone needs to do operations on block device, such as write and read, get info and etc.</source>
			<translation>深度备份还原工具需要对块设备进行读写和获取信息等操作</translation>
		</message>
	</context>
</TS>