<?xml version="1.0" ?><!DOCTYPE TS><TS language="bn" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!message" line="0"/>
			<source>Authentication is required to run Deepin Clone</source>
			<translation>ডিপিন ক্লোন চালাতে প্রমাণীকরণ প্রয়োজন</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!description" line="0"/>
			<source>Deepin Clone needs to do operations on block device, such as write and read, get info and etc.</source>
			<translation>ডিপিন ক্লোনের ব্লক ডিভাইসে অপারেশন করা প্রয়োজন, যেমন লেখা এবং পড়া , তথ্য নেয়া ইত্যাদি।</translation>
		</message>
	</context>
</TS>