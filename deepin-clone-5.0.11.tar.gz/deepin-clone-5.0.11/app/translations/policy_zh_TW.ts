<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_TW" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!message" line="0"/>
			<source>Authentication is required to run Deepin Clone</source>
			<translation>執行 Deepin 時光機需要身份驗證</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!description" line="0"/>
			<source>Deepin Clone needs to do operations on block device, such as write and read, get info and etc.</source>
			<translation>Deepin 時光機需要在區塊裝置做些動作，例如寫、讀、取得資訊等等。</translation>
		</message>
	</context>
</TS>