<?xml version="1.0" ?><!DOCTYPE TS><TS language="ro" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!message" line="0"/>
			<source>Authentication is required to run Deepin Clone</source>
			<translation>Autentificarea este necesară pentru a executa Deepin Clone</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!description" line="0"/>
			<source>Deepin Clone needs to do operations on block device, such as write and read, get info and etc.</source>
			<translation>Deepin Clone necesită executarea unor operațiuni asupra dispozitivului tip bloc, cum ar fi scriere și citire, obținerea informațiilor etc.</translation>
		</message>
	</context>
</TS>