<?xml version="1.0" ?><!DOCTYPE TS><TS language="nl" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!message" line="0"/>
			<source>Authentication is required to run Deepin Clone</source>
			<translation>Wachtwoord vereist om Deepin Klonen uit te voeren</translation>
		</message>
		<message>
			<location filename="com.deepin.pkexec.deepin-clone!description" line="0"/>
			<source>Deepin Clone needs to do operations on block device, such as write and read, get info and etc.</source>
			<translation>Deepin Klonen moet handelingen uitvoeren op block-apparaten, zoals schrijven en lezen, informatie opvragen, enz.</translation>
		</message>
	</context>
</TS>